import { describe, it, expect, beforeEach } from 'vitest';
import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import App from './App';

describe('App', () => {
  beforeEach(() => {
    localStorage.clear();
  });

  it('renders the app', () => {
    render(<App />);
    expect(screen.getByRole('heading', { name: /expense tracker/i })).toBeInTheDocument();
  });

  it('adds an expense', async () => {
    const user = userEvent.setup();
    render(<App />);

    await user.type(screen.getByLabelText(/title/i), 'Coffee');
    await user.type(screen.getByLabelText(/amount/i), '4.50');
    await user.selectOptions(screen.getByLabelText(/^category$/i), 'Food');
    await user.click(screen.getByRole('button', { name: /add expense/i }));

    expect(screen.getByText('Coffee')).toBeInTheDocument();
    expect(screen.getAllByText('$4.50').length).toBeGreaterThan(0);
  });

  it('calculates the total with the category fee', async () => {
    const user = userEvent.setup();
    render(<App />);

    await user.type(screen.getByLabelText(/title/i), 'Coffee');
    await user.type(screen.getByLabelText(/amount/i), '100');
    await user.selectOptions(screen.getByLabelText(/^category$/i), 'Food');
    await user.click(screen.getByRole('button', { name: /add expense/i }));

    // Food fee rate is 5%: 100 + 5 = 105.
    expect(screen.getAllByText('$100.00').length).toBeGreaterThan(0);
    expect(screen.getByText('$5.00')).toBeInTheDocument();
    expect(screen.getByText('$105.00')).toBeInTheDocument();
  });
});
