# Project memory

## Product intent & audience

- Expense tracker app: add expenses (title, amount, category), filter by category, view totals with category-based fee/tax calculations.
- Data persists in browser localStorage.
- Audience: developers/AI coding agents working iteratively through a numbered task workflow.

## Brand personality & voice

- Technical, precise, documentation-first. Values explicit boundaries and intentional deferral of known weaknesses.

## Visual design & UX direction

- Tailwind CSS utility classes for styling; lucide-react for icons.
- Single-page UI surface: form, category filter, expense list, totals.
- Production-quality aesthetic expected (per `.bolt/prompt`); no concrete palette/typography decisions inferred yet.

## Decisions, constraints & rationale

- Stack: React 18 + TypeScript (strict) + Vite; Vitest + React Testing Library for tests.
- Architecture: UI layer (`src/App.tsx`) owns React state and delegates domain logic to strategy layer (`src/strategies/`).
- Strategy pattern refactoring (Task #03): fee rates extracted from App.tsx into `src/strategies/feeStrategy.ts` with `FeeCalculationStrategy` interface, concrete strategies, registry, and `calculateFee` helper. Removed duplicated `CATEGORY_FEE_RATES` object and switch statement.
- Fee rates: Food 5%, Transport 3%, Utilities 8%, Entertainment 10%.
- Category type: `'Food' | 'Transport' | 'Utilities' | 'Entertainment'`.
- Domain logic must be pure functions (no side effects, no React state, no DOM) to stay independently testable.
- Unit tests required for every domain module; UI changes covered in App.test.tsx.
- AGENTS.md created: documents purpose, architecture, safe commands, conventions, forbidden actions (no secrets, no unapproved deploys, no destructive commands, no unreviewed dependency changes).
- README.md created matching actual project structure and scripts.
- Scripts: `npm install`, `npm run dev`, `npm test` (vitest run), `npm run typecheck` (tsc --noEmit), `npm run lint`, `npm run build`.
- Test status: 7 tests pass (3 App + 4 feeStrategy); typecheck, lint, build all clean.

## Open questions & assumptions

- Task #07 will address two intentionally deferred weaknesses after a risk audit: missing input validation on add-expense form and unsafe `JSON.parse` of localStorage without try/catch.
- Numbered task workflow exists beyond Tasks #02/#03/#07; full task list not yet visible.
- No concrete visual design tokens (colors, typography, spacing scale) decided yet beyond Tailwind defaults.