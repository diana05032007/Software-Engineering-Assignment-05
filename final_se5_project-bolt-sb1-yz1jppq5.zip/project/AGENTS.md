# AGENTS.md

Guidance for AI coding agents and human contributors working on this repository.

## Project Purpose & Architecture

This is an **Expense Tracker** web application: users can add expenses (title, amount, category), filter them by category, and see totals with category-based fee/tax rates applied. Expenses persist in the browser's `localStorage`.

Stack: **React 18 + TypeScript + Vite**, styled with Tailwind CSS, tested with **Vitest + React Testing Library**.

Architecture:

- `src/App.tsx` — the single UI surface. Renders the form, category filter, expense list, and totals. Owns all React state and delegates fee calculation to the strategy layer.
- `src/strategies/feeStrategy.ts` — domain/strategy layer. Defines the `FeeCalculationStrategy` interface, one concrete strategy per category (Food 5%, Transport 3%, Utilities 8%, Entertainment 10%), and a registry that resolves a strategy from a category.
- `src/App.test.tsx` — UI-level tests (render, add expense, total calculation).
- `src/strategies/feeStrategy.test.ts` — unit tests for the fee strategies and registry.

## Setup & Safe Commands

```bash
npm install          # install dependencies
npm run dev          # start the dev server
npm test             # run the Vitest suite (vitest run)
npm run typecheck    # tsc --noEmit against the app tsconfig
npm run lint         # ESLint over the repo
npm run build        # production build to dist/
```

All of these commands are safe to run; none of them modify remote state or deploy anything.

## Coding Conventions

- **Strict TypeScript.** Every function parameter and return value is typed; no implicit `any`. Run `npm run typecheck` before finishing any change.
- **Pure calculation functions.** Domain logic (fees, totals, filtering) must be pure functions of their inputs — no side effects, no React state, no DOM access. This keeps the strategy layer independently testable.
- **Unit tests required for domain logic.** Every module under `src/strategies/` (and any future domain module) must have a matching `.test.ts` with tests covering each branch. UI behavior changes in `App.tsx` should be covered in `App.test.tsx`.
- UI uses Tailwind utility classes; icons come from `lucide-react` when needed.

## Forbidden Actions & Boundaries

- **NO secrets or API keys committed.** Never hardcode or commit credentials, tokens, or `.env` values.
- **NO production deployments without human approval.** Do not publish, deploy, or push this app anywhere without an explicit go-ahead from a human.
- **NO destructive commands.** Never run `rm -rf`, `git reset --hard`, or similar commands that could irreversibly delete work.
- **NO unreviewed dependency additions/removals in `package.json`.** Any change to dependencies requires human review of the package name, version, and reason.
