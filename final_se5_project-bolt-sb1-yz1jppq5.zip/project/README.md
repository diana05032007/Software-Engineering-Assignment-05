# Expense Tracker

A simple expense tracker built with React, TypeScript, and Vite. Add expenses with a title, amount, and category; filter them by category; and see totals with category-based fee rates applied. Expenses are saved in your browser's localStorage.

## Features

- Add an expense (title, amount, category: Food, Transport, Utilities, Entertainment)
- Filter the expense list by category
- Total calculation with a per-category fee rate (Food 5%, Transport 3%, Utilities 8%, Entertainment 10%)
- Persistence in localStorage

## Getting Started

```bash
npm install
npm run dev
```

## Scripts

| Script              | Description                              |
| ------------------- | ---------------------------------------- |
| `npm run dev`       | Start the Vite development server        |
| `npm test`          | Run the Vitest test suite                |
| `npm run typecheck` | Type-check the project with `tsc --noEmit` |
| `npm run lint`      | Lint the project with ESLint             |
| `npm run build`     | Production build to `dist/`              |
| `npm run preview`   | Preview the production build             |

## Project Structure

```
.
├── AGENTS.md                  # Guidance for AI agents & contributors
├── index.html
├── package.json
├── src
│   ├── App.tsx                # UI: form, filter, expense list, totals
│   ├── App.test.tsx           # UI tests (Vitest + React Testing Library)
│   ├── strategies
│   │   ├── feeStrategy.ts     # Fee calculation strategy pattern
│   │   └── feeStrategy.test.ts
│   ├── main.tsx
│   ├── setupTests.ts
│   ├── index.css
│   └── vite-env.d.ts
├── tailwind.config.js
├── vite.config.ts
└── tsconfig*.json
```

## Testing

Unit tests use Vitest with React Testing Library in a jsdom environment. Run them with `npm test`.

## Known Limitations

This is a baseline implementation kept intentionally simple:

- No input validation on the add-expense form
- Unsafe `JSON.parse` when reading localStorage (corrupted storage crashes the app)
