import { useEffect, useState } from 'react';
import { calculateFee, resolveFeeStrategy, type Category } from './strategies/feeStrategy';

interface Expense {
  id: string;
  title: string;
  amount: number;
  category: Category;
}

const CATEGORIES: Category[] = ['Food', 'Transport', 'Utilities', 'Entertainment'];

const STORAGE_KEY = 'expenses';

function isValidExpense(value: unknown): value is Expense {
  if (typeof value !== 'object' || value === null) return false;
  const e = value as Record<string, unknown>;
  return (
    typeof e.id === 'string' &&
    typeof e.title === 'string' &&
    e.title.trim() !== '' &&
    typeof e.amount === 'number' &&
    Number.isFinite(e.amount) &&
    e.amount > 0 &&
    CATEGORIES.includes(e.category as Category)
  );
}

function loadExpenses(): Expense[] {
  const raw = localStorage.getItem(STORAGE_KEY);
  if (raw === null) return [];
  try {
    const parsed: unknown = JSON.parse(raw);
    if (!Array.isArray(parsed)) {
      saveExpenses([]);
      return [];
    }
    const valid = parsed.filter(isValidExpense);
    saveExpenses(valid);
    return valid;
  } catch {
    // Corrupted or invalid storage: reset it and start from an empty list.
    saveExpenses([]);
    return [];
  }
}

function saveExpenses(expenses: Expense[]) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(expenses));
}

function App() {
  const [expenses, setExpenses] = useState<Expense[]>(() => loadExpenses());
  const [filterCategory, setFilterCategory] = useState<'All' | Category>('All');
  const [title, setTitle] = useState('');
  const [amount, setAmount] = useState('');
  const [category, setCategory] = useState<Category>('Food');
  const [validationError, setValidationError] = useState('');

  useEffect(() => {
    saveExpenses(expenses);
  }, [expenses]);

  const visibleExpenses =
    filterCategory === 'All' ? expenses : expenses.filter((e) => e.category === filterCategory);

  const total = visibleExpenses.reduce((sum, e) => sum + e.amount, 0);
  const totalFee = visibleExpenses.reduce(
    (sum, e) => sum + calculateFee(e.category, e.amount),
    0
  );
  const grandTotal = total + totalFee;

  const addExpense = () => {
    const trimmedTitle = title.trim();
    const parsedAmount = parseFloat(amount);

    if (trimmedTitle === '') {
      setValidationError('Please enter a title for the expense.');
      return;
    }
    if (!Number.isFinite(parsedAmount) || parsedAmount <= 0) {
      setValidationError('Please enter a positive amount greater than zero.');
      return;
    }

    setValidationError('');
    const newExpense: Expense = {
      id: crypto.randomUUID(),
      title: trimmedTitle,
      amount: parsedAmount,
      category,
    };
    setExpenses([...expenses, newExpense]);
    setTitle('');
    setAmount('');
  };

  return (
    <div className="min-h-screen bg-slate-100 text-slate-900">
      <div className="max-w-2xl mx-auto px-4 py-10">
        <h1 className="text-3xl font-bold mb-6">Expense Tracker</h1>

        <form
          className="bg-white rounded-lg shadow p-4 mb-6 flex flex-wrap gap-3 items-end"
          onSubmit={(e) => {
            e.preventDefault();
            addExpense();
          }}
        >
          <label className="flex-1 min-w-[160px] text-sm font-medium">
            Title
            <input
              className="mt-1 w-full border border-slate-300 rounded px-3 py-2"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
            />
          </label>
          <label className="w-32 text-sm font-medium">
            Amount
            <input
              className="mt-1 w-full border border-slate-300 rounded px-3 py-2"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              type="number"
            />
          </label>
          <label className="w-40 text-sm font-medium">
            Category
            <select
              className="mt-1 w-full border border-slate-300 rounded px-3 py-2 bg-white"
              value={category}
              onChange={(e) => setCategory(e.target.value as Category)}
            >
              {CATEGORIES.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>
          </label>
          <button
            type="submit"
            className="bg-slate-900 text-white rounded px-4 py-2 hover:bg-slate-700 transition-colors"
          >
            Add Expense
          </button>
          {validationError && (
            <p role="alert" className="w-full text-sm text-red-600 font-medium">
              {validationError}
            </p>
          )}
        </form>

        <div className="bg-white rounded-lg shadow p-4 mb-6">
          <label className="text-sm font-medium">
            Filter by category
            <select
              className="mt-1 ml-2 border border-slate-300 rounded px-3 py-2 bg-white"
              value={filterCategory}
              onChange={(e) => setFilterCategory(e.target.value as 'All' | Category)}
            >
              <option value="All">All</option>
              {CATEGORIES.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>
          </label>
        </div>

        <ul className="bg-white rounded-lg shadow divide-y divide-slate-200 mb-6">
          {visibleExpenses.map((e) => (
            <li key={e.id} className="flex items-center justify-between px-4 py-3">
              <div>
                <p className="font-medium">{e.title}</p>
                <p className="text-sm text-slate-500">
                  {e.category} · fee {resolveFeeStrategy(e.category).rate * 100}%
                </p>
              </div>
              <span className="font-semibold">${e.amount.toFixed(2)}</span>
            </li>
          ))}
          {visibleExpenses.length === 0 && (
            <li className="px-4 py-3 text-slate-500">No expenses yet.</li>
          )}
        </ul>

        <div className="bg-slate-900 text-white rounded-lg shadow p-4 space-y-1">
          <p>
            Subtotal: <span className="font-semibold">${total.toFixed(2)}</span>
          </p>
          <p>
            Category fees: <span className="font-semibold">${totalFee.toFixed(2)}</span>
          </p>
          <p className="text-lg">
            Total with fees: <span className="font-semibold">${grandTotal.toFixed(2)}</span>
          </p>
        </div>
      </div>
    </div>
  );
}

export default App;
