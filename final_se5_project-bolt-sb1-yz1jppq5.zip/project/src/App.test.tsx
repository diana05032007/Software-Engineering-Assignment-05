import { describe, it, expect, beforeEach } from 'vitest';
import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import App from './App';

describe('App', () => {
  beforeEach(() => {
    localStorage.clear();
  });

  it('renders the app', () => {
    render(<App />);
    expect(screen.getByRole('heading', { name: /expense tracker/i })).toBeInTheDocument();
  });

  it('adds an expense', async () => {
    const user = userEvent.setup();
    render(<App />);

    await user.type(screen.getByLabelText(/title/i), 'Coffee');
    await user.type(screen.getByLabelText(/amount/i), '4.50');
    await user.selectOptions(screen.getByLabelText(/^category$/i), 'Food');
    await user.click(screen.getByRole('button', { name: /add expense/i }));

    expect(screen.getByText('Coffee')).toBeInTheDocument();
    expect(screen.getAllByText('$4.50').length).toBeGreaterThan(0);
  });

  it('calculates the total with the category fee', async () => {
    const user = userEvent.setup();
    render(<App />);

    await user.type(screen.getByLabelText(/title/i), 'Coffee');
    await user.type(screen.getByLabelText(/amount/i), '100');
    await user.selectOptions(screen.getByLabelText(/^category$/i), 'Food');
    await user.click(screen.getByRole('button', { name: /add expense/i }));

    // Food fee rate is 5%: 100 + 5 = 105.
    expect(screen.getAllByText('$100.00').length).toBeGreaterThan(0);
    expect(screen.getByText('$5.00')).toBeInTheDocument();
    expect(screen.getByText('$105.00')).toBeInTheDocument();
  });

  it('rejects an empty title with a visible validation error and does not add the expense', async () => {
    const user = userEvent.setup();
    render(<App />);

    await user.type(screen.getByLabelText(/amount/i), '10');
    await user.click(screen.getByRole('button', { name: /add expense/i }));

    expect(screen.getByRole('alert')).toHaveTextContent(/please enter a title/i);
    expect(screen.getByText(/no expenses yet/i)).toBeInTheDocument();
    expect(screen.queryByText('$10.00')).not.toBeInTheDocument();
    expect(localStorage.getItem('expenses')).toBe('[]');
  });

  it.each([-5, '0', 'abc'])('rejects an invalid amount of %s', async (invalidAmount) => {
    const user = userEvent.setup();
    render(<App />);

    await user.type(screen.getByLabelText(/title/i), 'Coffee');
    await user.clear(screen.getByLabelText(/amount/i));
    await user.type(screen.getByLabelText(/amount/i), String(invalidAmount));
    await user.click(screen.getByRole('button', { name: /add expense/i }));

    expect(screen.getByRole('alert')).toHaveTextContent(/positive amount greater than zero/i);
    expect(screen.getByText(/no expenses yet/i)).toBeInTheDocument();
    expect(screen.queryByText('Coffee')).not.toBeInTheDocument();
    expect(localStorage.getItem('expenses')).toBe('[]');
  });

  it('recovers gracefully from corrupted JSON in localStorage', () => {
    localStorage.setItem('expenses', '{bad-json');

    expect(() => render(<App />)).not.toThrow();
    expect(screen.getByText(/no expenses yet/i)).toBeInTheDocument();
    expect(localStorage.getItem('expenses')).toBe('[]');
  });

  it('discards entries with an invalid shape from localStorage', () => {
    localStorage.setItem(
      'expenses',
      JSON.stringify([
        { id: '1', title: 'Coffee', amount: -3, category: 'Food' },
        { id: '2', title: 'Bus', amount: 2, category: 'Bogus' },
        { id: '3', title: 'Snack', amount: 7, category: 'Food' },
      ])
    );

    render(<App />);

    expect(screen.queryByText('Coffee')).not.toBeInTheDocument();
    expect(screen.queryByText('Bus')).not.toBeInTheDocument();
    expect(screen.getByText('Snack')).toBeInTheDocument();
  });
});
