export type Category = 'Food' | 'Transport' | 'Utilities' | 'Entertainment';

export interface FeeCalculationStrategy {
  readonly category: Category;
  readonly rate: number;
  calculate(amount: number): number;
}

class CategoryFeeStrategy implements FeeCalculationStrategy {
  constructor(
    readonly category: Category,
    readonly rate: number
  ) {}

  calculate(amount: number): number {
    return amount * this.rate;
  }
}

export const foodFeeStrategy = new CategoryFeeStrategy('Food', 0.05);
export const transportFeeStrategy = new CategoryFeeStrategy('Transport', 0.03);
export const utilitiesFeeStrategy = new CategoryFeeStrategy('Utilities', 0.08);
export const entertainmentFeeStrategy = new CategoryFeeStrategy('Entertainment', 0.1);

const registry: Record<Category, FeeCalculationStrategy> = {
  Food: foodFeeStrategy,
  Transport: transportFeeStrategy,
  Utilities: utilitiesFeeStrategy,
  Entertainment: entertainmentFeeStrategy,
};

export function resolveFeeStrategy(category: Category): FeeCalculationStrategy {
  return registry[category];
}

export function calculateFee(category: Category, amount: number): number {
  return resolveFeeStrategy(category).calculate(amount);
}
