import { describe, it, expect } from 'vitest';
import {
  foodFeeStrategy,
  transportFeeStrategy,
  utilitiesFeeStrategy,
  entertainmentFeeStrategy,
  resolveFeeStrategy,
  calculateFee,
} from './feeStrategy';

describe('feeStrategy', () => {
  it('applies the correct rate per category strategy', () => {
    expect(foodFeeStrategy.calculate(100)).toBe(5); // 5%
    expect(transportFeeStrategy.calculate(100)).toBe(3); // 3%
    expect(utilitiesFeeStrategy.calculate(100)).toBe(8); // 8%
    expect(entertainmentFeeStrategy.calculate(100)).toBe(10); // 10%
  });

  it('resolves a strategy for every category', () => {
    expect(resolveFeeStrategy('Food').category).toBe('Food');
    expect(resolveFeeStrategy('Transport').category).toBe('Transport');
    expect(resolveFeeStrategy('Utilities').category).toBe('Utilities');
    expect(resolveFeeStrategy('Entertainment').category).toBe('Entertainment');
  });

  it('calculates the fee through the registry', () => {
    expect(calculateFee('Food', 200)).toBe(10);
    expect(calculateFee('Entertainment', 50)).toBe(5);
  });

  it('returns zero fee for a zero amount', () => {
    expect(calculateFee('Food', 0)).toBe(0);
  });
});
